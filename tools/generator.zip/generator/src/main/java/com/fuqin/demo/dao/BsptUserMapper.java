package com.fuqin.demo.dao;

import com.fuqin.demo.model.BsptUser;

public interface BsptUserMapper {
    int deleteByPrimaryKey(String userId);

    int insert(BsptUser record);

    int insertSelective(BsptUser record);

    BsptUser selectByPrimaryKey(String userId);

    int updateByPrimaryKeySelective(BsptUser record);

    int updateByPrimaryKey(BsptUser record);
}