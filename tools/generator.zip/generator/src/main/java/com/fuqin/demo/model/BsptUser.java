package com.fuqin.demo.model;

import java.util.Date;

public class BsptUser {
    /**
     * 
     */
    private String userId;

    /**
     * 
     */
    private String cName;

    /**
     * 
     */
    private String defaultLangage;

    /**
     * 
     */
    private Integer passWordChangeDays;

    /**
     * 
     */
    private Date passWordLastChangeDate;

    /**
     * 
     */
    private String nodeId;

    /**
     * 
     */
    private Integer orderBy;

    /**
     * 
     */
    private String userName;

    /**
     * 
     */
    private Integer sex;

    /**
     * 
     */
    private String officePhone;

    /**
     * 
     */
    private String officeAddress;

    /**
     * 
     */
    private Integer enableStatus;

    /**
     * 
     */
    private Date createOn;

    /**
     * 
     */
    private String createByName;

    /**
     * 
     */
    private String updateBy;

    /**
     * 
     */
    private Date updateOn;

    /**
     * 
     */
    public String getUserId() {
        return userId;
    }

    /**
     * 
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * 
     */
    public String getcName() {
        return cName;
    }

    /**
     * 
     */
    public void setcName(String cName) {
        this.cName = cName;
    }

    /**
     * 
     */
    public String getDefaultLangage() {
        return defaultLangage;
    }

    /**
     * 
     */
    public void setDefaultLangage(String defaultLangage) {
        this.defaultLangage = defaultLangage;
    }

    /**
     * 
     */
    public Integer getPassWordChangeDays() {
        return passWordChangeDays;
    }

    /**
     * 
     */
    public void setPassWordChangeDays(Integer passWordChangeDays) {
        this.passWordChangeDays = passWordChangeDays;
    }

    /**
     * 
     */
    public Date getPassWordLastChangeDate() {
        return passWordLastChangeDate;
    }

    /**
     * 
     */
    public void setPassWordLastChangeDate(Date passWordLastChangeDate) {
        this.passWordLastChangeDate = passWordLastChangeDate;
    }

    /**
     * 
     */
    public String getNodeId() {
        return nodeId;
    }

    /**
     * 
     */
    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    /**
     * 
     */
    public Integer getOrderBy() {
        return orderBy;
    }

    /**
     * 
     */
    public void setOrderBy(Integer orderBy) {
        this.orderBy = orderBy;
    }

    /**
     * 
     */
    public String getUserName() {
        return userName;
    }

    /**
     * 
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * 
     */
    public Integer getSex() {
        return sex;
    }

    /**
     * 
     */
    public void setSex(Integer sex) {
        this.sex = sex;
    }

    /**
     * 
     */
    public String getOfficePhone() {
        return officePhone;
    }

    /**
     * 
     */
    public void setOfficePhone(String officePhone) {
        this.officePhone = officePhone;
    }

    /**
     * 
     */
    public String getOfficeAddress() {
        return officeAddress;
    }

    /**
     * 
     */
    public void setOfficeAddress(String officeAddress) {
        this.officeAddress = officeAddress;
    }

    /**
     * 
     */
    public Integer getEnableStatus() {
        return enableStatus;
    }

    /**
     * 
     */
    public void setEnableStatus(Integer enableStatus) {
        this.enableStatus = enableStatus;
    }

    /**
     * 
     */
    public Date getCreateOn() {
        return createOn;
    }

    /**
     * 
     */
    public void setCreateOn(Date createOn) {
        this.createOn = createOn;
    }

    /**
     * 
     */
    public String getCreateByName() {
        return createByName;
    }

    /**
     * 
     */
    public void setCreateByName(String createByName) {
        this.createByName = createByName;
    }

    /**
     * 
     */
    public String getUpdateBy() {
        return updateBy;
    }

    /**
     * 
     */
    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    /**
     * 
     */
    public Date getUpdateOn() {
        return updateOn;
    }

    /**
     * 
     */
    public void setUpdateOn(Date updateOn) {
        this.updateOn = updateOn;
    }
}