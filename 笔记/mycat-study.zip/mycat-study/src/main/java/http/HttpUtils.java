package http;

import org.apache.http.HttpEntity;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.util.List;


public class HttpUtils {


	/**
	 * http post请求传参的方法 返回实体
	 */
	public static CloseableHttpResponse httpPostWithPAaram(String url,List<BasicNameValuePair> formparams,int timeout) throws Exception {
		// 创建默认的httpClient实例.
		CloseableHttpClient httpclient = HttpClients.createDefault();
		CloseableHttpResponse response = null;
		// 创建httppost
		HttpPost httppost = new HttpPost(url);
		RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(timeout).setConnectTimeout(timeout).build();
		httppost.setConfig(requestConfig);
		if (null != formparams) {
			UrlEncodedFormEntity uefEntity = new UrlEncodedFormEntity(formparams, "UTF-8");
			httppost.setEntity(uefEntity);
		}
		response = httpclient.execute(httppost);

		HttpEntity entit = response.getEntity();
		System.out.println(EntityUtils.toString(entit,"utf-8"));
		return response;

	}

	/**
	 * http post请求传参的方法 返回实体
	 */
	public static CloseableHttpResponse httpPostWithPAaram(String url,String json) throws Exception {
		// 创建默认的httpClient实例.
		CloseableHttpClient httpclient = HttpClients.createDefault();
		CloseableHttpResponse response = null;
		// 创建httppost
		HttpPost httppost = new HttpPost(url);
		StringEntity uefEntity = new StringEntity(json);
		uefEntity.setContentEncoding("UTF-8");
		uefEntity.setContentType("application/json");
		httppost.setEntity(uefEntity);
		response = httpclient.execute(httppost);
		return response;
	}

	/**
	 * http post请求传参的方法 返回实体
	 */
	public static CloseableHttpResponse httpPostWithPAaram(String url) throws Exception {
		// 创建默认的httpClient实例.
		CloseableHttpClient httpclient = HttpClients.createDefault();
		CloseableHttpResponse response = null;
		// 创建httppost
		HttpPost httppost = new HttpPost(url);
		response = httpclient.execute(httppost);
		return response;
	}
}
