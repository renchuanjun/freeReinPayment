package http;

/**
 * @author 任传君
 * @create 2018-07-05 15:47
 **/
public class INFAParam implements java.io.Serializable{

    private String id;

    /**
     * 日期字符串
     * 每日定时统一发送的字符串格式 yyyyMMdd
     * 每日实时发送的字符串格式为yyyyMMddHHmmSS
     */
    private String data;

    /**
     * 拼接好的字符串内容
     */
    private StringBuffer content;

    /**
     * 系统ID
     * 1:统计监测二期
     * 2:登记系统
     */
    private String systemid;

    /**
     * 业务类型
     * 24:互联网债权类融资
     * 26:互联网金融产品及收益权转让融资
     * 33:登记系统业务数据
     * 34:登记系统合同模板文件
     */
    private String stype;

    /**
     * 文件名称
     * inv_contract.csv	合同要素信息
     * general_contract.csv	合同模板约定条款
     * pro_repay_record.csv	借款人项目还款记录
     * contract_state.csv	合同状态变更
     * inv_return_record.csv	出借人回款记录
     */
    private String fileName;

    /**
     * 发送.zip 的随机数
     *  每日固定发送的文件随机数范围001--999
     *  实时发送文件随机数范围0001--9999
     *
     */
    private String randoms;

    /**
     * 启动方式1手动 2自动
     */
    private Integer startWay;

    /**
     * 备注
     * @return
     */
    private String remarks;
    /**
     * 身份证号
     */
    private String sno;
    /**
     * 查询原因
     */
    private String sreason;
    /**
     * 用户姓名
     */
    private String sname;


    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getSreason() {
        return sreason;
    }

    public void setSreason(String sreason) {
        this.sreason = sreason;
    }

    public String getSno() {
        return sno;
    }

    public void setSno(String sno) {
        this.sno = sno;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Integer getStartWay() {
        return startWay;
    }

    public void setStartWay(Integer startWay) {
        this.startWay = startWay;
    }

    public String getRandoms() {
        return randoms;
    }

    public void setRandoms(String randoms) {
        this.randoms = randoms;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getSystemid() {
        return systemid;
    }

    public void setSystemid(String systemid) {
        this.systemid = systemid;
    }

    public String getStype() {
        return stype;
    }

    public void setStype(String stype) {
        this.stype = stype;
    }

    public StringBuffer getContent() {
        return content;
    }

    public void setContent(StringBuffer content) {
        this.content = content;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
