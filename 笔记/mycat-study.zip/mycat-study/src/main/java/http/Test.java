package http;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.io.IOUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.message.BasicNameValuePair;

import java.util.*;


/**
 * @author 任传君
 * @create 2018-11-02 16:54
 **/
public class Test {

    //String[][] notNullArr11 = new String[][]{{"TRANCODE","交易类型"},{"UNIQUECODE","交易唯一标识"},{"ORDERID","交易订单号"},{"APPLYDATE","交易时间"},{"TRANSID","交易ID"}};


    // 35
    public static void main(String [] args) throws Exception {
//        收取借款人费用();
        内部户转账();
//        提现();
    }


    /**
     * 账务接口
     * @param notNullArr
     * @throws Exception
     */
    private static void 账务(String[][] notNullArr,String url) throws Exception {
        JSONObject jsonObject = new JSONObject();
        for (int i = 0; i < notNullArr.length; i++) {
            String[] parm = notNullArr[i];
            String key = parm[0];
            String value = parm[1];
            jsonObject.put(key,value);
        }
        List<BasicNameValuePair> formparams = new ArrayList<>(1);
        JSONArray array = JSONArray.fromObject(jsonObject);
        String jsonstr = array.toString();
        jsonstr = jsonstr.replaceAll("\\[","").replaceAll("]","");
        BasicNameValuePair basicNameValuePair = new BasicNameValuePair("jsonstr",jsonstr);
        formparams.add(basicNameValuePair);
        System.out.println(jsonstr);
        CloseableHttpResponse response = HttpUtils.httpPostWithPAaram(url,formparams,1000*60*60);
    }


    public static void 提现() throws Exception {
         String 提现接口 = "http://localhost:8080/fuqin-lfacct/dps/AcctWithdrawl.action";
        String[][] notNullArr11 = new String[][]{{"TRANCODE","4"},{"UNIQUECODE",getRandomChar(6)},{"USERID","10000"},
                {"ORDERID","11111"},{"APPLYDATE","2018-11-11 00:00:00"},{"TRANSID","222"},{"TRANSAMT","10"}};
        账务(notNullArr11,提现接口);
       // {"TRANCODE":"4","UNIQUECODE":"11111","USERID":"40234","ORDERID":"22222","APPLYDATE":"2018-3-20","TRANSID":"222","TRANSAMT":"3"}
    }


    public static void 收取借款人费用() throws Exception {
        String 收取借款人费用 = "http://localhost:8080/fuqin-lfacct/dps/AcctExpenses.action";
        String[][] notNullArr = new String[][]{{"TRANCODE","97"},{"UNIQUECODE",getRandomChar(6)},
                {"ORDERID","11111"},{"APPLYDATE","2018-11-11 00:00:00"},{"TRANSID","11111"},
                {"USERID","10000"},{"TRANSAMT","1"},{"PROJCODE","1111"},{"PROJNAME","测试仙姑"},
                {"ACCID","100086"},{"MEMOCODE","11111"}};
        账务(notNullArr,收取借款人费用);

    }
    public static void  内部户转账() throws Exception {

        String  内部户转账 = "http://localhost:8080/fuqin-lfacct/dps/AcctTransfer.action";
        String[][] notNullArr = new String[][]{{"TRANCODE","98"},{"UNIQUECODE",getRandomChar(6)},
                {"ORDERID","11111"},{"APPLYDATE","2018-11-11 00:00:00"},{"TRANSID","11111"},
                {"USERID","10000"},{"TRANSAMT","10"},{"PROJCODE","1111"},{"PROJNAME","测试仙姑"},
                {"ACCID","100086"},{"MEMOCODE","0013"},{"PROJCODE","111"},{"PROJNAME","111"},{"TENDERID","11111"},
                {"REPAYSEQ","1"}};

        账务(notNullArr, 内部户转账);

    }


    public static String getRandomChar(int length) {            //生成随机字符串
        char[] chr = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
        Random random = new Random();
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < length; i++) {
            buffer.append(chr[random.nextInt(10)]);
        }
        return buffer.toString();
    }

}
