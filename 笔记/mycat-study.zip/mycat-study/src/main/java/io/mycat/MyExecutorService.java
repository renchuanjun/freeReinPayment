package io.mycat;


import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * @author 任传君
 * @create 2018-10-31 10:28
 **/
public class MyExecutorService {

    private ReentrantReadWriteLock reentrantReadWriteLock = new ReentrantReadWriteLock();

    public static void main(String [] args ){


    }

    private void a(){
        reentrantReadWriteLock.readLock().lock();
        try {



        }finally {
            reentrantReadWriteLock.readLock().unlock();
        }
    }

}
