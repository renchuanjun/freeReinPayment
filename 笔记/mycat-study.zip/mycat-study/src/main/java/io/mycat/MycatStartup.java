package io.mycat;


import io.mycat.config.model.A;
import util.MyArrayList;

import java.util.*;
import java.util.concurrent.CountDownLatch;


/**
 * @author 任传君
 * @create 2018-10-15 14:32
 **/
public class MycatStartup{

    private static final String dateFormt = "yyyy-MM-dd HH:mm:ss";

    private static final String ZK_CONFIG_FILE_NAME = "/myid.properties";

    private static List<Object> list;

    private static Object obj = new Object();

    private static boolean bool = true;

    private static final CountDownLatch latch=new CountDownLatch(2);

    public static void main(String [] args) throws InterruptedException {
        System.out.println("1111");

         list = new MyArrayList<>(10000000);
        long begin_1 = System.currentTimeMillis();
        for (int i = 0; i < 10000000; i++) {
//            SystemConfig config = new SystemConfig();
            list.add(dateFormt);
        }
        long end_1 = System.currentTimeMillis();
        System.out.println("MyArrayList添加用时 :" + (end_1 - begin_1));

        for (int j = 9999999; j > 9990000; j--) {
            A a = new A();
            a.setI(j);
            a.setList(list);
            Thread thread = new Thread(a);
            thread.start();
            thread.join();
        }

        synchronized (list){
            System.out.println("唤醒");
            list.notifyAll();
        }

    }



















    public static void  removeList( int original ,int delete,int index){
        int a = original-delete;

        int c = original/5000;
        if (0 != original%500){
            c = c+1;
        }
        List<List<String>> list = new ArrayList<>(c);

        TreeMap treeMap = new TreeMap();
        treeMap.put("11",11);
        treeMap.remove("11");

        TreeSet treeSet = new TreeSet();

        List<Object> list_1 = new LinkedList<>();
        long beginLinkedList_1 = System.currentTimeMillis();
        for (int m = 0; m < 10000000; m++) {
            list_1.add(dateFormt);
        }
        long endLinkedList_1 = System.currentTimeMillis();
        System.out.println("LinkedList天假用时 :" + (endLinkedList_1 - beginLinkedList_1));
        //////////////////////////////////////////////////////////////////////////////////
        long beginLinkedList = System.currentTimeMillis();
        for (int n = 9999999; n > 9990000; n--) {
            list_1.remove(n);
        }
        long endLinkedList = System.currentTimeMillis();
        System.out.println("LinkedList删除用时 :" + (endLinkedList - beginLinkedList));
    }
}

































