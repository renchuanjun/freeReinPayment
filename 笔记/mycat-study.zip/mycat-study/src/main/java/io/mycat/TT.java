package io.mycat;

/**
 * @author 任传君
 * @create 2018-11-09 16:17
 **/
public class TT implements Runnable {

    int b= 100;



    public synchronized  void m1(String name) throws InterruptedException {
            b = 1000;
            Thread.sleep(500);
            System.out.println("b = "+name+" =====" +b+"优先级 "+Thread.currentThread().getPriority());
    }


    public synchronized void m2(String name) throws InterruptedException {
        Thread.sleep((250));
        b = 2000;
//        System.out.println("m2 = " + name + " ====" + b);
    }

    @Override
    public void run() {
        try {
            m1(Thread.currentThread().getName());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String [] args) throws InterruptedException {
        for (int i = 0; i < 1000; i++) {
            TT tt = new TT();
            Thread thread = new Thread(tt);
            thread.start();
            tt.m2(Thread.currentThread().getName());
            System.out.println("main = " + tt.b);
            Thread.sleep(5*1000);

        }
    }
}
