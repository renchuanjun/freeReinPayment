package io.mycat.config;

/**
 * @author 任传君
 * @create 2018-10-30 16:07
 **/
public class Node<T> {

    private int no;

    private T value;

    private volatile Node<T> next;

    public Node(T value) {
        this.value = value;
    }

    public Node(Node<T> next) {
        this.next = next;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public Node<T> getNext() {
        return next;
    }

    public void setNext(Node<T> next) {
        this.next = next;
    }
}
