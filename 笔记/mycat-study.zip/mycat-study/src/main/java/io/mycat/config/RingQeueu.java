package io.mycat.config;


import java.util.Calendar;
import java.util.HashMap;

/**
 * @author 任传君
 * @create 2018-10-30 16:03
 **/
public class RingQeueu<T> {

    private Node [] table;

    private int size;


    public RingQeueu(int initialCapacity) {
        this.table = new Node[initialCapacity];
    }


    public boolean put(T value) {
        return putVal(value);
    }

    final private boolean putVal(T value) {
        Calendar calendar = Calendar.getInstance();
        int seconds = calendar.get(Calendar.SECOND);
        Node<T>[] tab; Node<T> p ,e; int n, i;
        tab = table;
        if ((p = tab[i = (seconds - 1)]) == null)
            tab[i] = new Node<T>(value);
        else{
            synchronized (p) {
                for (; ;) {
                    if ( (e = p.getNext()) == null) {
                        p.setNext(new Node<T>(value));
                        break;
                    }else{
                        p = e;
                    }
                }
            }
        }
        return false;
    }


    final private Node getVal(int hash) {
        Node[] tab; Node first, e; int n;
        if ((tab = table) != null && (n = tab.length) > 0
                && (first = tab[hash]) != null ){
            removeNode(hash);
            return first;
        }
        return null;
    }


    final void removeNode(int hash) {
        Node[] tab; Node p; int n;
        if ((tab = table) != null && (n = tab.length) > 0 &&(p = tab[hash]) != null) {
            tab[hash] = p.getNext();
        }
    }
}
