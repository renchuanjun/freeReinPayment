package io.mycat.config;

import util.MyArrayList;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author 任传君
 * @create 2018-10-25 9:08
 **/
public class Test1 {

    private static  RingQeueu<User> ringQeueu = new RingQeueu(60);

    public static void main(String [] args) throws InterruptedException {

        /*new Thread(new Runnable() {
            @Override
            public void run() {
               int i = 0;
                while (true) {
                   User user = new User();
                   user.setName("张三" + i++);
                   ringQeueu.put(user);
                    try {
                        Thread.sleep(1*1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });*/
//        Thread.sleep(1000*60);

//        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap(1);
        int i = 0;
        while (true) {
            User user = new User();
            user.setName("张三" + (i+=1) );
            ringQeueu.put(user);
//            concurrentHashMap.put(i,user);
        }


    }
}
