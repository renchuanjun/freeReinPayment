package io.mycat.config;

import sun.reflect.generics.tree.Tree;

import java.util.*;

/**
 * @author 任传君
 * @create 2018-10-25 11:47
 **/
public class TextVector {

    public static void main(String [] args){

        /*Set dset = new HashSet();
        dset.add(2);
        dset.add(1);
        dset.add(3);
        dset.add(5);
        dset.add(4);
        Iterator iterator = dset.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next() + " ");
        }

        Set set = new LinkedHashSet();
        set.add(2);
        set.add(1);
        set.add(4);
        set.add(5);
        set.add(3);
        Iterator iterator1 = set.iterator();
        while (iterator1.hasNext()) {
            System.out.print(iterator1.next() + " ");
        }*/

        HashMap hashMap = new HashMap(1,10);
        hashMap.get("11");
//        hashMap.put("111",1111);
//        hashMap.put("222",1111);
//        hashMap.put("333",1111);
//        hashMap.put("444",1111);
//        hashMap.put("555",1111);
//        hashMap.put("666",1111);
//        hashMap.put("7777",1111);
//        hashMap.put("888",1111);
//        hashMap.put("1010",1111);
//        hashMap.put("1111",1111);
//        hashMap.put("1212",1111);
//        hashMap.put("1313",1111);
//        hashMap.put("1515",1111);
//        hashMap.put("1414",1111);
//        hashMap.put("1616",1111);
//        hashMap.put("1717",1111);
//        hashMap.put("1818",1111);
//        System.out.println(111);
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.get("11");
        linkedHashMap.put("","");

    }
}
