package io.mycat.config;

/**
 * @author 任传君
 * @create 2018-10-30 17:10
 **/
public class User {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
