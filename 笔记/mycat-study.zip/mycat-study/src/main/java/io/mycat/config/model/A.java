package io.mycat.config.model;

import java.util.List;

/**
 * @author 任传君
 * @create 2018-11-06 9:56
 **/
public class A implements Runnable {

    private List<Object> list;

    private int aBoolean = 1;

    private int i ;

    public void setI(int i) {
        this.i = i;
    }

    public void setaBoolean(int aBoolean) {
        this.aBoolean = aBoolean;
    }

    public void setList(List<Object> list) {
        this.list = list;
    }

    @Override
    public void run() {
        try {
            if(1 == aBoolean){
                aBoolean = aBoolean - 1;
                 synchronized (list){
                    list.wait();
                }
            }
             Thread.sleep(11);
//            System.out.println(Thread.currentThread().getName()+"唤醒");
            list.remove(9999);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
