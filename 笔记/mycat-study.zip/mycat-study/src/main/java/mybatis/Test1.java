package mybatis;

import mybatis.mapper.OrderHistoryMapper;
import mybatis.pojo.OrderHistory;
import org.apache.ibatis.session.SqlSession;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CountDownLatch;

/**
 * @author 任传君
 * @create 2018-11-07 17:31
 **/
public class Test1 {
    private static List<OrderHistory> list = new ArrayList<>(200000);

    private static CountDownLatch countDownLatch = new CountDownLatch(2);

    private static int ooo = 100000;

    public static void main(String args[]) throws InterruptedException {
        multiThreadImport(5);
    }



    public static void multiThreadImport(int ThreadNum){
        List<OrderHistory> lists = new ArrayList<>(ooo/ThreadNum);
        for (int i = 0; i < ooo/ThreadNum; i++) {
            OrderHistory orderHistory = aaa();
            lists.add(orderHistory);
        }
        System.out.println("封装数据结束插入开始");
        final CountDownLatch countDownLatch = new CountDownLatch(ThreadNum);
        long begin_1 = System.currentTimeMillis();
        for (int i = 0; i < ThreadNum; i++) {
            new Thread(()->{
                selectMember(lists);
                countDownLatch.countDown();
            }).start();
        }
        try {
            System.out.println("11111");
            countDownLatch.await();
            long end_1 = System.currentTimeMillis();
            System.out.println("MyArrayList添加用时 :" + (end_1 - begin_1));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void multiThreadUpdate(int ThreadNum) throws InterruptedException {
        final CountDownLatch countDownLatch = new CountDownLatch(ThreadNum);
        long begin_1 = System.currentTimeMillis();
        for (int i = 0; i < ThreadNum; i++) {
            OrderHistory orderHistory = new OrderHistory();
            orderHistory.setId(1680650);
            orderHistory.setName10(1);
            new Thread(()->{
                updateMember(orderHistory);
                countDownLatch.countDown();
            }).start();
        }
        countDownLatch.await();
        long end_1 = System.currentTimeMillis();
        System.out.println("MyArrayList添加用时 :" + (end_1 - begin_1));
    }


    private static void updateMember(OrderHistory orderHistory) {
        try {
            // 连接数据库，并得到数据库操作对象
            SqlSession openSession = MybatisUtil.openSqlSession();
            // 得到mapper对象（该对象在mybatis-config.xml中要配置正确）
            OrderHistoryMapper mapper = openSession.getMapper(OrderHistoryMapper.class);
            // 然后调用方法执行封装的sql语句
            OrderHistory member = mapper.selectByPrimaryKey(1);
//            System.out.println(member.getId());
            mapper.updateByPrimaryKeys(orderHistory);
            // 最后关闭连接
            openSession.commit();
            openSession.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }



    private static void selectMember(List<OrderHistory> lists) {
        try {
            // 连接数据库，并得到数据库操作对象
            SqlSession openSession = MybatisUtil.openSqlSession();
            // 得到mapper对象（该对象在mybatis-config.xml中要配置正确）
            OrderHistoryMapper mapper = openSession.getMapper(OrderHistoryMapper.class);
            // 然后调用方法执行封装的sql语句
            OrderHistory member = mapper.selectByPrimaryKey(1);
//            System.out.println(member.getId());
            mapper.insert(lists);
            // 最后关闭连接
            openSession.commit();
            openSession.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    private static OrderHistory aaa(){
        OrderHistory orderHistory = new OrderHistory();
        orderHistory.setName1(getRandomChar(450));
        orderHistory.setName2(getRandomChar(245));
        orderHistory.setName3(getRandomChar(40));
        orderHistory.setName4(getRandomChar(getRandom(1, 44)));
        orderHistory.setName6(getRandomChar(getRandom(1, 44)));
        orderHistory.setName7(getRandomChar(getRandom(1, 44)));
        orderHistory.setName8(randomDate("2000-07-01 00:00:00","2018-07-01 00:00:00"));
        orderHistory.setName9(randomDate("2000-07-01 00:00:00","2018-07-01 00:00:00"));
        orderHistory.setName10(getRandom(0, 3));
        orderHistory.setName11(getRandomChar(getRandom(1, 10)));
        orderHistory.setName12(getRandomChar(getRandom(1, 8)));
        orderHistory.setName13(getRandomChar(getRandom(1, 11)));
        orderHistory.setName14(getRandomChar(getRandom(1, 221)));
        orderHistory.setName15(getRandomChar(getRandom(1, 9)));
        orderHistory.setName16(getRandomChar(getRandom(1, 9)));
        orderHistory.setName17(getRandomChar(getRandom(1, 19)));
        orderHistory.setName18(getRandomChar(getRandom(1, 110)));
        orderHistory.setName19(getRandomChar(getRandom(1, 19)));
        orderHistory.setName20(getRandomChar(getRandom(1, 19)));
        return orderHistory;
    }


    public static String getRandomChar(int length) {            //生成随机字符串
        char[] chr = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
                'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
        Random random = new Random();
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < length; i++) {
            buffer.append(chr[random.nextInt(36)]);
        }
        return buffer.toString();
    }

    public static int getRandom(int min, int max){
        Random random = new Random();
        int s = random.nextInt(max) % (max - min + 1) + min;
        return s;

    }


    /**
     * 获取随机日期
     * @param beginDate 起始日期，格式为：yyyy-MM-dd
     * @param endDate 结束日期，格式为：yyyy-MM-dd
     * @return
     */
    private static Date randomDate(String beginDate, String endDate){
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date start = format.parse(beginDate);
            Date end = format.parse(endDate);

            if(start.getTime() >= end.getTime()){
                return null;
            }

            long date = random(start.getTime(),end.getTime());

            return new Date(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static long random(long begin,long end){
        long rtn = begin + (long)(Math.random() * (end - begin));
        if(rtn == begin || rtn == end){
            return random(begin,end);
        }
        return rtn;
    }

}
