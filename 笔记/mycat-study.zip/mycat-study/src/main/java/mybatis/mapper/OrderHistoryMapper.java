package mybatis.mapper;

import mybatis.pojo.OrderHistory;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface OrderHistoryMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(List<OrderHistory> record);

    int insertSelective(OrderHistory record);

    OrderHistory selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(OrderHistory record);

    int updateByPrimaryKey(OrderHistory record);

    int updateByPrimaryKeys(OrderHistory record);
}