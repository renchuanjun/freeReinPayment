package mybatis.pojo;

import java.math.BigDecimal;

public class Table1 {
    /**
     * 
     */
    private Integer id;

    /**
     * 
     */
    private String name;

    /**
     * 
     */
    private BigDecimal age;

    /**
     * 
     */
    public Integer getId() {
        return id;
    }

    /**
     * 
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 
     */
    public String getName() {
        return name;
    }

    /**
     * 
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 
     */
    public BigDecimal getAge() {
        return age;
    }

    /**
     * 
     */
    public void setAge(BigDecimal age) {
        this.age = age;
    }
}