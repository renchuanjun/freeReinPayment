package sync;

import java.util.Objects;

/**
 * @author 任传君
 * @create 2018-11-16 10:14
 **/
public class TTT {

    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TTT ttt = (TTT) o;
        return Objects.equals(id, ttt.id);
    }

}
