package sync;

import java.util.Random;

/**
 * @author 任传君
 * @create 2018-11-16 10:16
 **/
public class Test implements Runnable {

    private static int i = 0;
    @Override
    public void run() {

        JavaRowLock lock = JavaRowLock.getJavaRowLock();
        String l = getRandomChar();
        try {
            try {
                lock.lock(l);
                i++;
                System.out.println(i);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }finally {
            lock.unLock(l);
        }
    }

    public static void main(String []args){
        Test test = new Test();
        for (int j = 0; j < 100000; j++) {
            new Thread(test).start();
        }

    }

    public static String getRandomChar() {            //生成随机字符串
        char[] chr = {'0'};
        Random random = new Random();
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < 4; i++) {
            buffer.append(chr[random.nextInt(1)]);
        }
        return buffer.toString();

    }

}
